package com.example.hp.activitytest.model;

import java.io.Serializable;

public class MessageApply implements Serializable {

}
